The web application is meant to classify email text as spam ot not.

Dataset link: https://www.kaggle.com/datasets/shantanudhakadd/email-spam-detection-dataset-classification


https://www.kaggle.com/code/aditikumari1710/email-spam-prediction-97
